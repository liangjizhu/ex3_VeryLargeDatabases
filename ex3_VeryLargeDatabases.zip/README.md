# ex3_VeryLargeDatabases

```sudo ./setup_vldb.sh```